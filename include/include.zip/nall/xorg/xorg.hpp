#ifndef NALL_XORG_XORG_HPP
#define NALL_XORG_XORG_HPP

#include <nall/xorg/guard.hpp>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <nall/xorg/guard.hpp>

#endif
