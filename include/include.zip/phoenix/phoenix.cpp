#ifndef PHOENIX_CPP
#define PHOENIX_CPP

#include "core/core.cpp"

#endif
