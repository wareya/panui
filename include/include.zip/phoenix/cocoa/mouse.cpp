namespace phoenix {

Position pMouse::position() {
  return {0, 0};
}

bool pMouse::pressed(Mouse::Button button) {
  return false;
}

}
