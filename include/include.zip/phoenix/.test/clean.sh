rm test-gtk
rm test-qt
rm test-reference
rm test-windows.exe
