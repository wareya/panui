namespace phoenix {

void pMenu::append(Action& action) {
}

void pMenu::remove(Action& action) {
}

void pMenu::setImage(const image& image) {
}

void pMenu::setText(string text) {
}

void pMenu::constructor() {
}

void pMenu::destructor() {
}

}
