namespace phoenix {

void pCheckItem::setChecked(bool checked) {
}

void pCheckItem::setText(string text) {
}

void pCheckItem::constructor() {
}

void pCheckItem::destructor() {
}

}
