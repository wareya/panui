namespace phoenix {

string pFont::serif(unsigned size, string style) {
  return "";
}

string pFont::sans(unsigned size, string style) {
  return "";
}

string pFont::monospace(unsigned size, string style) {
  return "";
}

Size pFont::size(string font, string text) {
  return {0, 0};
}

}
