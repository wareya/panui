namespace phoenix {

void pHorizontalScroller::setLength(unsigned length) {
}

void pHorizontalScroller::setPosition(unsigned position) {
}

void pHorizontalScroller::constructor() {
}

void pHorizontalScroller::destructor() {
}

}
