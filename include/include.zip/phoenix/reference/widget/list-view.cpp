namespace phoenix {

void pListView::append(const lstring& text) {
}

void pListView::autoSizeColumns() {
}

void pListView::remove(unsigned selection) {
}

void pListView::reset() {
}

void pListView::setCheckable(bool checkable) {
}

void pListView::setChecked(unsigned selection, bool checked) {
}

void pListView::setHeaderText(const lstring& text) {
}

void pListView::setHeaderVisible(bool visible) {
}

void pListView::setImage(unsigned selection, unsigned position, const image& image) {
}

void pListView::setSelected(bool selected) {
}

void pListView::setSelection(unsigned selection) {
}

void pListView::setText(unsigned selection, unsigned position, string text) {
}

void pListView::constructor() {
}

void pListView::destructor() {
}

}
