namespace phoenix {

void pComboButton::append(string text) {
}

void pComboButton::remove(unsigned selection) {
}

void pComboButton::reset() {
}

void pComboButton::setSelection(unsigned selection) {
}

void pComboButton::setText(unsigned selection, string text) {
}

void pComboButton::constructor() {
}

void pComboButton::destructor() {
}

}
