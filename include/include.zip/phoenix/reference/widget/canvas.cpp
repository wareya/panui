namespace phoenix {

void pCanvas::setDroppable(bool droppable) {
}

void pCanvas::setMode(Canvas::Mode mode) {
}

void pCanvas::setSize(Size size) {
}

void pCanvas::constructor() {
}

void pCanvas::destructor() {
}

}
