namespace phoenix {

void pCheckButton::setChecked(bool checked) {
}

void pCheckButton::setImage(const image& image, Orientation orientation) {
}

void pCheckButton::setText(string text) {
}

void pCheckButton::constructor() {
}

void pCheckButton::destructor() {
}

}
