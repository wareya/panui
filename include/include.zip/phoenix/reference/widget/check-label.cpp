namespace phoenix {

void pCheckLabel::setChecked(bool checked) {
}

void pCheckLabel::setText(string text) {
}

void pCheckLabel::constructor() {
}

void pCheckLabel::destructor() {
}

}
