namespace phoenix {

void pLineEdit::setEditable(bool editable) {
}

void pLineEdit::setText(string text) {
}

string pLineEdit::text() {
}

void pLineEdit::constructor() {
}

void pLineEdit::destructor() {
}

}
