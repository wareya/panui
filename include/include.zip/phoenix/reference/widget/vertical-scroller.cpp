namespace phoenix {

void pVerticalScroller::setLength(unsigned length) {
}

void pVerticalScroller::setPosition(unsigned position) {
}

void pVerticalScroller::constructor() {
}

void pVerticalScroller::destructor() {
}

}
