namespace phoenix {

void pHorizontalSlider::setLength(unsigned length) {
}

void pHorizontalSlider::setPosition(unsigned position) {
}

void pHorizontalSlider::constructor() {
}

void pHorizontalSlider::destructor() {
}

}
