namespace phoenix {

void pVerticalSlider::setLength(unsigned length) {
}

void pVerticalSlider::setPosition(unsigned position) {
}

void pVerticalSlider::constructor() {
}

void pVerticalSlider::destructor() {
}

}
