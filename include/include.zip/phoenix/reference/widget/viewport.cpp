namespace phoenix {

uintptr_t pViewport::handle() {
  return 0;
}

void pViewport::setDroppable(bool droppable) {
}

void pViewport::constructor() {
}

void pViewport::destructor() {
}

}
