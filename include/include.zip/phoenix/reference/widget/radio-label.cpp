namespace phoenix {

void pRadioLabel::setChecked() {
}

void pRadioLabel::setGroup(const group<RadioLabel>& group) {
}

void pRadioLabel::setText(string text) {
}

void pRadioLabel::constructor() {
}

void pRadioLabel::destructor() {
}

}
