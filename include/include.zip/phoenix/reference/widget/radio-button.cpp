namespace phoenix {

void pRadioButton::setChecked() {
}

void pRadioButton::setGroup(const group<RadioButton>& group) {
}

void pRadioButton::setImage(const image& image, Orientation orientation) {
}

void pRadioButton::setText(string text) {
}

void pRadioButton::constructor() {
}

void pRadioButton::destructor() {
}

}
