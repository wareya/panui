namespace phoenix {

void pTabFrame::append(string text, const image& image) {
}

void pTabFrame::remove(unsigned selection) {
}

void pTabFrame::setImage(unsigned selection, const image& image) {
}

void pTabFrame::setSelection(unsigned selection) {
}

void pTabFrame::setText(unsigned selection, string text) {
}

void pTabFrame::constructor() {
}

void pTabFrame::destructor() {
}

}
