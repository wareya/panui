namespace phoenix {

void pFrame::setText(string text) {
}

void pFrame::constructor() {
}

void pFrame::destructor() {
}

}
