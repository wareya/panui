namespace phoenix {

void pTimer::setEnabled(bool enabled) {
}

void pTimer::setInterval(unsigned interval) {
}

void pTimer::constructor() {
}

void pTimer::destructor() {
}

}
